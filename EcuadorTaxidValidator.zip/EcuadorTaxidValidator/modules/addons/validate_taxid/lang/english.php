<?php

$_LANG['taxiderror.empty'] = 'The TAX ID field cannot be empty.';
$_LANG['taxiderror.invalidcedula'] = 'The Ecuadorian ID number is not valid.';
$_LANG['taxiderror.invalidruc'] = 'The Ecuadorian RUC number is not valid.';
$_LANG['taxiderror.invalidformat'] = 'The TAX ID format is incorrect.';

