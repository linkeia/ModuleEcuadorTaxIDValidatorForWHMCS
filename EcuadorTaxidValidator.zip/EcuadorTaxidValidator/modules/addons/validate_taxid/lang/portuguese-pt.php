<?php

$_LANG['taxiderror.empty'] = 'O campo TAX ID não pode estar vazio.';
$_LANG['taxiderror.invalidcedula'] = 'O número de cédula equatoriana não é válido.';
$_LANG['taxiderror.invalidruc'] = 'O número de RUC equatoriano não é válido.';
$_LANG['taxiderror.invalidformat'] = 'O formato do TAX ID está incorreto.';

