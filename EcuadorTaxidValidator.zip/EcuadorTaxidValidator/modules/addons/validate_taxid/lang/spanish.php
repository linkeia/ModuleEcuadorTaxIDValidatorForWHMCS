<?php

$_LANG['taxiderror.empty'] = 'El campo TAX ID no puede estar vacío.';
$_LANG['taxiderror.invalidcedula'] = 'El número de cédula ecuatoriana no es válido.';
$_LANG['taxiderror.invalidruc'] = 'El número de RUC ecuatoriano no es válido.';
$_LANG['taxiderror.invalidformat'] = 'El formato del TAX ID es incorrecto.';

