<?php

if (!defined('WHMCS')) {
    die('Access Denied');
}

/**
 * Configuración del módulo
 */
function validate_taxid_config()
{
    return [
        'name' => 'Validación de TAX ID de Ecuador',
        'description' => 'Este módulo valida el TAX ID (Cédula o RUC) para usuarios de Ecuador en el registro y el checkout.',
        'version' => '1.2',
        'author' => '<img src="../modules/addons/validate_taxid/logo.png" style="height: 20px;">',
        'fields' => [
            'enableValidation' => [
                'FriendlyName' => 'Habilitar Validación',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Activa o desactiva la validación del TAX ID en los formularios de registro y checkout.',
            ],
        ],
    ];
}

/**
 * Activar el módulo
 */
function validate_taxid_activate()
{
    return ['status' => 'success', 'description' => 'El módulo de validación de TAX ID ha sido activado.'];
}

/**
 * Desactivar el módulo
 */
function validate_taxid_deactivate()
{
    return ['status' => 'success', 'description' => 'El módulo de validación de TAX ID ha sido desactivado.'];
}

/**
 * Configuración personalizable en el backend de WHMCS
 */
function validate_taxid_output($vars)
{
    $currentStatus = (bool) \WHMCS\Config\Setting::getValue('EnableTaxIdValidation');

    // Manejar la solicitud del usuario (encender/apagar validación)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggleTaxIdValidation'])) {
        $newStatus = !$currentStatus;
        \WHMCS\Config\Setting::setValue('EnableTaxIdValidation', $newStatus);
        $currentStatus = $newStatus;
    }

    // Generar contenido para el área de administración
    echo '<h2 style="font-size: 24px; font-weight: bold; margin-bottom: 10px;">Validación de TAX ID de Ecuador</h2>';
    echo '<p style="margin-bottom: 15px;">Al activar esta opción, se validará el campo TAX ID con los algoritmos oficiales para detectar si el dato ingresado corresponde a un número de cédula de identidad o RUC de Ecuador válido.</p>';
    echo '<div style="background-color: #ffeb3b; padding: 10px; border: 1px solid #f1c40f; margin-bottom: 20px;">';
    echo '<strong>Importante:</strong> Para que este módulo funcione correctamente, es necesario que el soporte para TAX ID e impuestos esté habilitado en tu sistema WHMCS. Puedes hacerlo accediendo a los ajustes, entrando en la configuración de impuestos y activando la opción de soporte tributario.';
    echo '</div>';
    echo '<p style="font-style: italic; margin-bottom: 20px;">Desarrollado por <strong>Linkeia Network</strong></p>';

    // Mostrar estado actual con colores
    echo '<p>Estado actual: <strong style="color: ' . ($currentStatus ? 'green' : 'red') . ';">' . 
         ($currentStatus ? 'Habilitado' : 'Deshabilitado') . 
         '</strong></p>';

    // Botón para habilitar o deshabilitar
    echo '<form method="POST">';
    echo '<input type="hidden" name="toggleTaxIdValidation" value="1">';
    echo '<button type="submit" class="btn ' . ($currentStatus ? 'btn-danger' : 'btn-success') . '">';
    echo $currentStatus ? 'Deshabilitar' : 'Habilitar';
    echo '</button>';
    echo '</form>';
}