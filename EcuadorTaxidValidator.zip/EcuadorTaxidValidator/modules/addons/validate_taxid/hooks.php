<?php

if (!defined('WHMCS')) {
    die('Access Denied');
}

use WHMCS\User\Client;

class TaxIdValidator
{
    private static $processed = false;

    public static function validate($country, $taxId, $context)
    {
        // Si ya se procesó un hook, no ejecutar nuevamente
        if (self::$processed) {
            return null;
        }

        // Validar solo si el país es Ecuador
        if (strtoupper($country) !== 'EC') {
            return null;
        }

        // Marcar como procesado
        self::$processed = true;

        // Verificar si el TAX ID está vacío
        if (empty($taxId)) {
            return Lang::trans('taxiderror.empty');
        }

        // Validar TAX ID: Cédula o RUC
        if (!self::isValidCedula($taxId) && !self::isValidRUC($taxId)) {
            if (strlen($taxId) == 10) {
                return Lang::trans('taxiderror.invalidcedula');
            } elseif (strlen($taxId) == 13) {
                return Lang::trans('taxiderror.invalidruc');
            } else {
                return Lang::trans('taxiderror.invalidformat');
            }
        }

        return null;
    }

    private static function isValidCedula($cedula)
    {
        if (!preg_match('/^\d{10}$/', $cedula)) return false;

        $provincia = substr($cedula, 0, 2);
        $coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2];
        $suma = 0;

        if ($provincia < 1 || $provincia > 24) return false;

        for ($i = 0; $i < 9; $i++) {
            $digito = $cedula[$i] * $coeficientes[$i];
            $suma += ($digito > 9) ? ($digito - 9) : $digito;
        }

        $verificador = (10 - ($suma % 10)) % 10;
        return $verificador == $cedula[9];
    }

    private static function isValidRUC($ruc)
    {
        if (!preg_match('/^\d{13}$/', $ruc)) return false;

        $tercerDigito = (int) $ruc[2];

        if (in_array($tercerDigito, [0, 1, 2, 3, 4, 5])) {
            return self::isValidCedula(substr($ruc, 0, 10)) && self::isValidEstablecimiento(substr($ruc, 10, 3));
        } elseif ($tercerDigito == 9) {
            return self::isValidRUCPrivado($ruc);
        } elseif ($tercerDigito == 6) {
            return self::isValidRUCPublico($ruc);
        }

        return false;
    }

    private static function isValidEstablecimiento($establecimiento)
    {
        return (int)$establecimiento > 0;
    }

    private static function isValidRUCPrivado($ruc)
    {
        $coeficientes = [4, 3, 2, 7, 6, 5, 4, 3, 2];
        $suma = 0;

        for ($i = 0; $i < 9; $i++) {
            $suma += $ruc[$i] * $coeficientes[$i];
        }

        $verificador = 11 - ($suma % 11);
        return ($verificador == 11 ? 0 : $verificador) == $ruc[9];
    }

    private static function isValidRUCPublico($ruc)
    {
        $coeficientes = [3, 2, 7, 6, 5, 4, 3, 2];
        $suma = 0;

        for ($i = 0; $i < 8; $i++) {
            $suma += $ruc[$i] * $coeficientes[$i];
        }

        $verificador = 11 - ($suma % 11);
        return ($verificador == 11 ? 0 : $verificador) == $ruc[8];
    }
}

// Hook para Registro
add_hook('ClientDetailsValidation', 1, function ($vars) {
    $error = TaxIdValidator::validate($vars['country'] ?? '', $vars['tax_id'] ?? '', 'registration');
    return $error ? ['tax_id' => $error] : [];
});

// Hook para Checkout
add_hook('ShoppingCartValidateCheckout', 1, function ($vars) {
    $country = App::getFromRequest('country');
    $taxId = App::getFromRequest('tax_id');
    $error = TaxIdValidator::validate($country, $taxId, 'checkout');
    return $error ? ['tax_id' => $error] : [];
});
